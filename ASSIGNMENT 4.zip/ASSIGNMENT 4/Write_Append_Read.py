with open('output.txt','w') as f:
    content =  input("Enter text to write to the file: ")
    f.write(content)
    print("Data successfully written to ",f.name)

with open('output.txt','a') as file:
    appendcontent = input("Enter additional text to append : ")
    file.write('\n'+appendcontent)
    print("Data successfully appended.")

with open('output.txt','r') as file:
    lines = file.readlines()
    print("Final content of ",file.name)
    for i in lines:
        print(i)

