try:
    with open("sample.txt",'r') as f:
        lines =  f.readlines()
        for line in lines:
            print(line)


except FileNotFoundError:
    print("Error: The file ‘simple.txt’ was not found")
