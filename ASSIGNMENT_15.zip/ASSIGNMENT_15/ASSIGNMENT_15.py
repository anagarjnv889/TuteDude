from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time

driver = webdriver.Safari()
driver.maximize_window()
driver.get("https://www.amazon.in")
searchbar = driver.find_element(By.ID, "twotabsearchtextbox")
searchbar.send_keys("Samsung Phone")

searchbutton = driver.find_element(By.ID, "nav-search-submit-button")
searchbutton.click()

list = driver.find_elements(By.CLASS_NAME, "a-price-whole")
for i in list:
    print(f"prices : {i.text}")
time.sleep(5)
driver.quit()